from typing import Union, List, Optional
from typing_extensions import Annotated
from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
import models
from db import engine, SessionLocal
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

app = FastAPI(
    title= "Platinum Filings API",
    description= "An API for accessing Florida filing data",
    version="1.0.0"
)
models.Base.metadata.create_all(bind=engine)

origins = [
    "http://localhost.tiangolo.com",
    "https://localhost.tiangolo.com",
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:5173",
    "https://localhost:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def getDB():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

db_dependancy = Annotated[Session, Depends(getDB)]

@app.get("/")
def root():
    return {"Hello": "Welcome to FAST API"}
    
@app.get("/getById/{user_id}")
async def getById(db: db_dependancy, user_id: int):
    try:
        query = text("SELECT * FROM cordataq4 LIMIT 1")
        result = db.execute(query)
        
        column_names = result.keys()
        
        rows = result.fetchall()

        print("Column Names:", column_names)
        
        if rows:
            data = []
            for row in rows:
                row_dict = dict(zip(column_names, row))
                data.append(row_dict)
            return data
        else:
            raise HTTPException(status_code=404, detail="No data found")
    except HTTPException:
        raise
    except Exception as e:
        print(f"An error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")